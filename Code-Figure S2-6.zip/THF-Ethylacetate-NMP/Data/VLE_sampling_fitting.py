# -*- coding: utf-8 -*-
"""
Created on Mon May 15 17:47:38 2023

@author: zhangx
"""
# %% import package

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.io
from thermo.unifac import UFIP, UFSG, UNIFAC
from thermo import Wilson
from sklearn.base import clone
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.pipeline import Pipeline
from lmfit import Model

np.seterr(divide='ignore', invalid='ignore')

# %% initial data

Pressure = 101325

Comp_A = 'THF'
Antoine_A = {'A': 9.12118, 'B': 1202.942, 'C': -46.818}

Comp_B = 'Ethyl acetate'
Antoine_B = {'A': 9.22809, 'B': 1245.702, 'C': -55.189}

Comp_S = 'NMP'
Antoine_S = {'A': 9.673163, 'B': 1979.68, 'C': -50.95}

# %% functions

def Antoine(Antoine_para, T):
    
    A = Antoine_para['A']
    B = Antoine_para['B']
    C = Antoine_para['C']
    Psat = np.power(10, A - B / (C + T))
    
    return Psat

def Tb(Antoine_para, P):
        
    A = Antoine_para['A']
    B = Antoine_para['B']
    C = Antoine_para['C']
    Boiling_point = B / (A - np.log10(P)) - C
    
    return Boiling_point

def Binary_Txy_Wilson_AB(Antoine_para, P):
    
    x_result = []
    y_result = []
    T_result = []
    
    Tb_light = Tb(Antoine_para[0], P)
    Tb_heavy = Tb(Antoine_para[1], P)
    Interval = int((Tb_heavy - Tb_light) * 100)
    T_start = Tb_heavy
    
    AS = [[0, -11.469], [7.223, 0]]
    BS = [[0, 3648.437], [-2310.347, 0]]
    
    for i in range(0, 101):
        
        x = [i*0.01, 1-i*0.01]
        x_result.append(x)
        
        if i == 0:
            y_result.append([0, 1])
            T_result.append(Tb_heavy)
        elif i == 100:
            y_result.append([1, 0])
            T_result.append(Tb_light)
        else:        
            T_guess = T_start + 1    
            for j in range(0, Interval):       
                gama = Wilson(T = T_guess, xs = x, lambda_as = AS, lambda_bs = BS)
                Psat_A = Antoine(Antoine_para[0], T_guess)
                Psat_B = Antoine(Antoine_para[1], T_guess)
                P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                if P_test > P:
                    T_guess -= 0.1
                elif P_test < P:
                    for k in range(0, 100):
                        T_guess += 0.001
                        gama = Wilson(T = T_guess, xs = x, lambda_as = AS, lambda_bs = BS)
                        Psat_A = Antoine(Antoine_para[0], T_guess)
                        Psat_B = Antoine(Antoine_para[1], T_guess)
                        P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                        if P_test >= P or k == 99:
                            y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                            y_result.append(y)
                            T_result.append(T_guess)
                            break
                    T_start = T_guess
                    break
                elif P_test == P:
                    y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                    y_result.append(y)
                    T_result.append(T_guess)
                    T_start = T_guess
                    break
    
    x_result = np.array(x_result)
    y_result = np.array(y_result)
    T_result = np.array(T_result)
    
    return x_result, y_result, T_result

def Binary_Txy_Wilson_AS(Antoine_para, P):
    
    x_result = []
    y_result = []
    T_result = []
    
    Tb_light = Tb(Antoine_para[0], P)
    Tb_heavy = Tb(Antoine_para[1], P)
    Interval = int((Tb_heavy - Tb_light) * 100)
    T_start = Tb_heavy
    
    AS = [[0, 0.004], [1.198, 0]]
    BS = [[0, -26.861], [-533.824, 0]]
    
    for i in range(0, 101):
        
        x = [i*0.01, 1-i*0.01]
        x_result.append(x)
        
        if i == 0:
            y_result.append([0, 1])
            T_result.append(Tb_heavy)
        elif i == 100:
            y_result.append([1, 0])
            T_result.append(Tb_light)
        else:        
            T_guess = T_start + 1    
            for j in range(0, Interval):       
                gama = Wilson(T = T_guess, xs = x, lambda_as = AS, lambda_bs = BS)
                Psat_A = Antoine(Antoine_para[0], T_guess)
                Psat_B = Antoine(Antoine_para[1], T_guess)
                P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                if P_test > P:
                    T_guess -= 0.1
                elif P_test < P:
                    for k in range(0, 100):
                        T_guess += 0.001
                        gama = Wilson(T = T_guess, xs = x, lambda_as = AS, lambda_bs = BS)
                        Psat_A = Antoine(Antoine_para[0], T_guess)
                        Psat_B = Antoine(Antoine_para[1], T_guess)
                        P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                        if P_test >= P or k == 99:
                            y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                            y_result.append(y)
                            T_result.append(T_guess)
                            break
                    T_start = T_guess
                    break
                elif P_test == P:
                    y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                    y_result.append(y)
                    T_result.append(T_guess)
                    T_start = T_guess
                    break
    
    x_result = np.array(x_result)
    y_result = np.array(y_result)
    T_result = np.array(T_result)
    
    return x_result, y_result, T_result

def Binary_Txy_Wilson_BS(Antoine_para, P):
    
    x_result = []
    y_result = []
    T_result = []
    
    Tb_light = Tb(Antoine_para[0], P)
    Tb_heavy = Tb(Antoine_para[1], P)
    Interval = int((Tb_heavy - Tb_light) * 100)
    T_start = Tb_heavy
    
    AS = [[0, -0.942], [-4.478, 0]]
    BS = [[0, 628.93], [807.887, 0]]
    
    for i in range(0, 101):
        
        x = [i*0.01, 1-i*0.01]
        x_result.append(x)
        
        if i == 0:
            y_result.append([0, 1])
            T_result.append(Tb_heavy)
        elif i == 100:
            y_result.append([1, 0])
            T_result.append(Tb_light)
        else:        
            T_guess = T_start + 1    
            for j in range(0, Interval):       
                gama = Wilson(T = T_guess, xs = x, lambda_as = AS, lambda_bs = BS)
                Psat_A = Antoine(Antoine_para[0], T_guess)
                Psat_B = Antoine(Antoine_para[1], T_guess)
                P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                if P_test > P:
                    T_guess -= 0.1
                elif P_test < P:
                    for k in range(0, 100):
                        T_guess += 0.001
                        gama = Wilson(T = T_guess, xs = x, lambda_as = AS, lambda_bs = BS)
                        Psat_A = Antoine(Antoine_para[0], T_guess)
                        Psat_B = Antoine(Antoine_para[1], T_guess)
                        P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                        if P_test >= P or k == 99:
                            y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                            y_result.append(y)
                            T_result.append(T_guess)
                            break
                    T_start = T_guess
                    break
                elif P_test == P:
                    y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                    y_result.append(y)
                    T_result.append(T_guess)
                    T_start = T_guess
                    break
    
    x_result = np.array(x_result)
    y_result = np.array(y_result)
    T_result = np.array(T_result)
    
    return x_result, y_result, T_result

def Ternary_Txy_Wilson(Antoine_para, P):
    
    x_result = []
    y_result = []
    T_result = []

    Tb_light = Tb(Antoine_para[0], P)
    Tb_mid   = Tb(Antoine_para[1], P)
    Tb_heavy = Tb(Antoine_para[2], P)
    Interval = int((Tb_heavy - Tb_light) * 500)
    
    AS = [[0, -11.469, 0.004], [7.223, 0, -0.942], [1.198, -4.478, 0]]
    BS = [[0, 3648.437, -26.861], [-2310.347, 0, 628.93], [-533.824, 807.887, 0]]
    
    for i in range(0, 101):
        T_start = Tb_heavy
        for j in range(0, i+1):
            
            x = [j*0.01, (i-j)*0.01, 1-i*0.01]
            x_result.append(x)
            
            if i == 0:
                y_result.append([0, 0, 1])
                T_result.append(Tb_heavy)
            elif i == 100 and j == 0:
                y_result.append([0, 1, 0])
                T_result.append(Tb_mid)
            elif i == 100 and j == 100:
                y_result.append([1, 0, 0])
                T_result.append(Tb_light)
            else:
                T_guess = T_start + 10
                for z in range(0, Interval):
                    gama = Wilson(T = T_guess, xs = x, lambda_as = AS, lambda_bs = BS)                   
                    Psat_A = Antoine(Antoine_para[0], T_guess)
                    Psat_B = Antoine(Antoine_para[1], T_guess)
                    Psat_C = Antoine(Antoine_para[2], T_guess)
                    P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B + gama.gammas()[2] * x[2] * Psat_C
                    if P_test > P:
                        T_guess -= 0.1
                    elif P_test < P:
                        for k in range(0, 100):
                            T_guess += 0.001
                            gama = Wilson(T = T_guess, xs = x, lambda_as = AS, lambda_bs = BS)
                            Psat_A = Antoine(Antoine_para[0], T_guess)
                            Psat_B = Antoine(Antoine_para[1], T_guess)
                            Psat_C = Antoine(Antoine_para[2], T_guess)
                            P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B + gama.gammas()[2] * x[2] * Psat_C
                            if P_test >= P or k == 99:
                                y = [gama.gammas()[0]* x[0] * Psat_A / P_test, gama.gammas()[1]* x[1] * Psat_B / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test - gama.gammas()[1]* x[1] * Psat_B / P_test]
                                y_result.append(y)
                                T_result.append(T_guess)
                                break
                        T_start = T_guess
                        break
                    elif P_test == P:
                        y = [gama.gammas()[0]* x[0] * Psat_A / P_test, gama.gammas()[1]* x[1] * Psat_B / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test - gama.gammas()[1]* x[1] * Psat_B / P_test]
                        y_result.append(y)
                        T_result.append(T_guess)
                        T_start = T_guess
                        break
                    
    x_result = np.array(x_result)
    y_result = np.array(y_result)
    T_result = np.array(T_result)
    
    return x_result, y_result, T_result

# %% functions

LR1 = LinearRegression()
LR2 = clone(LR1)

def dTdx_Binary(x, T):
    
    T_derivative = []
    for i in range(0, len(T)-1):
        if T[i+1] - T[i] < 0:
            T_derivative.append(1)
        else:
            T_derivative.append(0)          
    T_derivative = np.array(T_derivative)
    
    return T_derivative

def dydx_Binary(x, y):
    
    y_derivative = []
    for i in range(0, len(y)-1):
        if y[i+1] - y[i] > 0:
            y_derivative.append(1)
        else:
            y_derivative.append(0)
    y_derivative = np.array(y_derivative)   
    
    return y_derivative

def dTdx_Ternary(X_train, T_train):
    
    X_train = np.rint(X_train * 100)
    test_T = np.hstack([X_train, T_train.reshape(-1, 1)])
    dTdx1 = []
    dTdx2 = []
    for i in range(1, 100):
        test_x1 = test_T[test_T[:, 0] == i, :]
        test_x1 = test_x1[test_x1[:, 1].argsort()]    
        test_x2 = test_T[test_T[:, 1] == i, :]
        test_x2 = test_x2[test_x2[:, 0].argsort()]
        for j in range(0, 100 - i):
            if test_x1[j + 1, 2] - test_x1[j, 2] <= 0:
                dTdx1.append(1)
            else:
                dTdx1.append(0)
            if test_x2[j + 1, 2] - test_x2[j, 2] <= 0:
                dTdx2.append(1)
            else:
                dTdx2.append(0)
    
    return dTdx1 + dTdx2

def dydx_Ternary(X_train, Y_train):
    
    X_train = np.rint(X_train * 100)
    test_Y = np.hstack([X_train, Y_train.reshape(-1, 1)])
    dydx1 = []
    dydx2 = []
    for i in range(1, 100):
        test_x1 = test_Y[test_Y[:, 0] == i, :]
        test_x1 = test_x1[test_x1[:, 1].argsort()]
        test_x2 = test_Y[test_Y[:, 1] == i, :]
        test_x2 = test_x2[test_x2[:, 0].argsort()]
        for j in range(0, 100 - i):
            if test_x1[j + 1, 3] - test_x1[j, 3] <= 0:
                dydx1.append(1)
            else:
                dydx1.append(0)
            if test_x2[j + 1, 3] - test_x2[j, 3] >= 0:
                dydx2.append(1)
            else:
                dydx2.append(0)            
    
    return dydx1 + dydx2

def Max_underestimation(Y_train, Y_pred):
    
    Y_train_data = []
    Y_pred_data = []
    for i in range(len(Y_train)):
        if Y_train[i] >= 0.95:
            Y_train_data.append(Y_train[i])
            Y_pred_data.append(Y_pred[i])
    Y_train_data = np.array(Y_train_data)
    Y_pred_data = np.array(Y_pred_data)
    return max(Y_train_data - Y_pred_data)

def Derivative_compare(train, pred):
    
    count = 0
    for i in range(len(train)):
        if int(train[i]) == int(pred[i]):
            count += 1
            
    return count / len(train)

def One_One_Binary(x, a, b, A):
    return (a + b*x) / (A*x + 1)

def Two_One_Binary(x, a, b, c, A):
    return (a + b*x + c*x*x) / (A*x + 1)

def One_One_Ternary(x, y, a, b, c, A, B):
    return (a + b*x + c*y) / (A*x + B*y + 1)

def Two_One_Ternary(x, y, a, b, c, d, e, f, A, B):
    return (a + b*x + c*y + d*x*x + e*x*y + f*y*y) / (A*x + B*y + 1)

def Three_One_Ternary(x, y, a, b, c, d, e, f, g, h, i, j, A, B):
    return (a + b*x + c*y + d*x*x + e*x*y + f*y*y + g*x*x*x + h*x*x*y + i*x*y*y + j*y*y*y) / (A*x + B*y + 1)

def Two_Two_Ternary(x, y, a, b, c, d, e, f, A, B, C, D, E):
    return (a + b*x + c*y + d*x*x + e*x*y + f*y*y) / (A*x*x + B*x*y + C*y*y + D*x + E*y + 1)

def Three_Two_Ternary(x, y, a, b, c, d, e, f, g, h, i, j, A, B, C, D, E):
    return (a + b*x + c*y + d*x*x + e*x*y + f*y*y + g*x*x*x + h*x*x*y + i*x*y*y + j*y*y*y) / (A*x*x + B*x*y + C*y*y + D*x + E*y + 1)

# %% THF + Ethylacetate at 101325 Pa: https://doi.org/10.1016/j.molliq.2018.07.038     # perfect match

# x_exp = np.array([1,0.9391,0.8857,0.8267,0.7437,0.672,0.6021,0.5214,0.4815,0.4375,0.3847,0.329,0.2952,0.2575,0.2299,0.1831,0.1414,0.0987,0.057])
# y_exp = np.array([1,0.9535,0.9138,0.8692,0.804,0.7433,0.6838,0.6091,0.5724,0.5256,0.4711,0.4127,0.3767,0.3356,0.3046,0.2504,0.2,0.1467,0.0883])
# T_exp = np.array([338.94,339.55,340.05,340.4,341.05,341.75,342.45,343.13,343.6,344.22,344.77,345.45,345.86,346.25,346.65,347.33,347.8,348.4,348.95])

# Antoine_b = [Antoine_A, Antoine_B]
# x_pred, y_pred, T_pred = Binary_Txy_Wilson_AB(Antoine_b, Pressure)

# plt.plot(x_pred[:, 0], y_pred[:, 0], '-b', x_exp, y_exp, 'r*')
# plt.plot(x_pred[:, 0], T_pred, '-b', x_exp, T_exp, 'r*')

# %% THF + NMP at 101325 Pa: # perfect match

# x_exp = np.array([1,0.9601,0.8171,0.7382,0.6458,0.5995,0.4458,0.3815,0.2456,0.1577,0.1184,0.0919,0.066,0.0564,0.0386,0.0276,0.0198,0.0101])
# y_exp = np.array([1,0.9996,0.998,0.9967,0.9951,0.9939,0.9876,0.9825,0.9606,0.9173,0.8711,0.8114,0.7235,0.6734,0.5533,0.4461,0.3514,0.1996])
# T_exp = np.array([338.94,340.27,343.77,346.94,350.16,353.24,362.19,368.14,382.9,398.64,409.92,422.2,433.61,439.51,448.91,456.54,462.42,468.84])

# Antoine_b = [Antoine_A, Antoine_S]
# x_pred, y_pred, T_pred = Binary_Txy_Wilson_AS(Antoine_b, Pressure)

# plt.plot(x_pred[:, 0], y_pred[:, 0], '-b', x_exp, y_exp, 'r*')
# plt.plot(x_pred[:, 0], T_pred, '-b', x_exp, T_exp, 'r*')

# %% Ethylacetate + NMP at 101325 Pa

# x_exp = np.array([1,0.9641,0.9203,0.8917,0.7906,0.6777,0.5932,0.4889,0.4166,0.3052,0.2131,0.1711,0.1096,0.0671,0.0481,0.0267,0.0191,0.0103])
# y_exp = np.array([1,0.9993,0.9986,0.9982,0.9966,0.9944,0.9919,0.9869,0.9814,0.9662,0.9394,0.9161,0.853,0.7562,0.6728,0.5103,0.4179,0.2585])
# T_exp = np.array([350.25,351.06,352.18,353.07,356.22,359.5,362.97,368.26,372.88,382.93,394.11,400.24,414.47,428.41,438.31,450.82,457.2,464.72])

# Antoine_b = [Antoine_B, Antoine_S]
# x_pred, y_pred, T_pred = Binary_Txy_Wilson_BS(Antoine_b, Pressure)

# plt.plot(x_pred[:, 0], y_pred[:, 0], '-b', x_exp, y_exp, 'r*')
# plt.plot(x_pred[:, 0], T_pred, '-b', x_exp, T_exp, 'r*')

# %% Ternary THF + Ethylacetate + NMP at 101325

# x1_exp = np.array([0.5198,0.4879,0.4516,0.4285,0.3864,0.3534,0.3251,0.3001,0.2677,0.2417,0.213,0.1944,0.1709,0.1401,0.1019,0.0609,0.0347])
# x2_exp = np.array([0.0253,0.0483,0.0768,0.0979,0.1284,0.1681,0.2084,0.2318,0.2691,0.2993,0.3299,0.3492,0.3682,0.3975,0.4108,0.4678,0.4963])

# y1_exp = np.array([0.9619,0.9317,0.8933,0.8633,0.8128,0.7526,0.691,0.648,0.582,0.5275,0.4671,0.4278,0.3802,0.3157,0.2385,0.1502,0.0898])
# y2_exp = np.array([0.0297,0.0588,0.0971,0.127,0.176,0.2371,0.2982,0.3412,0.407,0.4621,0.5219,0.5612,0.6083,0.6726,0.7473,0.8334,0.8924])


# T_exp = np.array([356.22,357.27,358.43,358.99,360.52,360.99,361.12,361.76,362.21,362.55,363.05,363.35,363.98,364.55,366.55,367.75,368.24])

# x1_exp = np.rint(x1_exp * 100)
# x2_exp = np.rint(x2_exp * 100)

# Antoine_1 = [Antoine_A, Antoine_B, Antoine_S]
# x_pred, y_pred, T_pred = Ternary_Txy_Wilson(Antoine_1, Pressure)

# x_pred = np.rint(x_pred * 100)
# result = np.hstack([x_pred, y_pred, T_pred.reshape(-1, 1)])

# y1 = []
# y2 = []
# T = []
# for i in range(len(x1_exp)):
    
#     test = result[result[:, 0] == x1_exp[i], :]
#     test = test[test[:, 1] == x2_exp[i], :]
#     y1.append(test[:, 3])
#     y2.append(test[:, 4])
#     T.append(test[:, 6])

# y1 = np.array(y1)
# y2 = np.array(y2)
# T = np.array(T)

# plt.plot(y1_exp, y1, '*')      $ perfect
# plt.plot(y2_exp, y2, '*')      $ perfect
# plt.plot(T_exp, T, '*')        $ perfect

# %% Binary THF + NMP sampling & fitting

# Antoine_b = [Antoine_B, Antoine_S]
# x_result, y_result, T_result = Binary_Txy_Wilson_BS(Antoine_b, Pressure)

# X_train = x_result[:, 0]
# T_train = T_result
# dT_train = dTdx_Binary(X_train, T_train)

# model_Tx = Model(One_One_Binary, independent_vars = ['x'])
# model_Tx.set_param_hint('a', value = 471)
# model_Tx.set_param_hint('b', value = 100)
# model_Tx.set_param_hint('A', value = 1)

# Modelfit_Tx = model_Tx.fit(T_train, x = X_train)
# T_pred = Modelfit_Tx.eval(x = X_train)
# Rsquare = r2_score(T_train, T_pred)
# mae = mean_absolute_error(T_train, T_pred)
# deltaT = max(abs(T_train - T_pred.ravel()))
# dT_pred = dTdx_Binary(X_train, T_pred)
# dT_test = Derivative_compare(dT_train, dT_pred)
# print('Performance', Rsquare, deltaT, mae, dT_test)

# TCoeff_a = Modelfit_Tx.params['a'].value
# TCoeff_b = Modelfit_Tx.params['b'].value
# TCoeff_A = Modelfit_Tx.params['A'].value
# TCoeff = [TCoeff_a, TCoeff_b, TCoeff_A]

# plt.plot(X_train, T_train, '-r', label = 'train')
# plt.plot(X_train, T_pred, '-b', label = 'prediction')
# plt.legend(['train', 'prediction'])
# plt.show()

############################################################ y = f(x1) fitting

# X_train = np.concatenate((x_result[:, 0].reshape(-1, 1), T_pred.reshape(-1, 1)), axis = 1)
# Y_train = y_result[:, 0]
# dY_train = dydx_Binary(x_result[:, 0], Y_train)

# pf = PolynomialFeatures(degree = 3, include_bias = False)
# MP = Pipeline([('pf', pf), ('LR', LR1)])
# MP.fit(X_train, Y_train)

# Y_pred = MP.predict(X_train)
# Rsquare = r2_score(Y_train, Y_pred)
# deltaY = max(abs(Y_train - Y_pred))
# mae = mean_absolute_error(Y_train, Y_pred)
# dY_pred = dydx_Binary(x_result[:, 0], Y_pred)
# dY_test = Derivative_compare(dY_train, dY_pred)
# print(Rsquare, deltaY, mae, dY_test)

# Y_Coeff = MP['LR'].coef_
# Y_Intercept = MP['LR'].intercept_

# Y_Coeff = pd.DataFrame(Y_Coeff)
# Y_Coeff.to_excel('Y_Coeff.xlsx', index = False)

# plt.plot(x_result[:, 0], Y_train, '-r')
# plt.plot(x_result[:, 0], Y_pred, '-b')
# plt.legend(['train', 'prediction'])
# plt.show()

############################################################# save 

# Results = np.concatenate((x_result, y_result, T_result.reshape(-1, 1), T_pred.reshape(-1, 1), Y_pred.reshape(-1, 1)/100), axis = 1)
# Results = pd.DataFrame(Results)
# Results.columns = ['x1', 'x2', 'y1', 'y2', 'T', 'T_pred', 'Y_pred']

# Output = Results
# Output.to_excel('EA_NMP_Result.xlsx', index = False)

# %% Ternary THF + Ethylacetate + NMP sampling & fitting

# Antoine_t = [Antoine_A, Antoine_B, Antoine_S]
# x_result, y_result, T_result = Ternary_Txy_Wilson(Antoine_t, Pressure)

# Output = {'x': x_result, 'y': y_result, 'T': T_result}
# scipy.io.savemat('Ternary_VLE.mat', Output)

VLE = scipy.io.loadmat('Ternary_VLE.mat')
x_result = VLE['x']
y_result = VLE['y']
T_result = VLE['T']

X_train = x_result[:, 0:2]
X1_train = x_result[:, 0]
X2_train = x_result[:, 1]
T_train = T_result.ravel()
dT_train = dTdx_Ternary(X_train, T_train)

model_Txx = Model(Two_One_Ternary, independent_vars = ['x', 'y'])
model_Txx.set_param_hint('a', value = 400)
model_Txx.set_param_hint('b', value = 10000)
model_Txx.set_param_hint('c', value = 10000)
model_Txx.set_param_hint('d', value = -400)
model_Txx.set_param_hint('e', value = -2000)
model_Txx.set_param_hint('f', value = -1000)
model_Txx.set_param_hint('A', value = 30)
model_Txx.set_param_hint('B', value = 30)

Modelfit_Txx = model_Txx.fit(T_train, x = X1_train, y = X2_train)
T_pred = Modelfit_Txx.eval(x = X1_train, y = X2_train).ravel()
Rsquare = r2_score(T_train, T_pred)
mae = mean_absolute_error(T_train, T_pred)
deltaT = max(abs(T_pred - T_train))
dT_pred = dTdx_Ternary(X_train, T_pred)
dT_test = Derivative_compare(dT_train, dT_pred)
print(Rsquare, deltaT, mae, dT_test)

# TCoeff_a = Modelfit_Txx.params['a'].value
# TCoeff_b = Modelfit_Txx.params['b'].value
# TCoeff_c = Modelfit_Txx.params['c'].value
# TCoeff_d = Modelfit_Txx.params['d'].value
# TCoeff_e = Modelfit_Txx.params['e'].value
# TCoeff_f = Modelfit_Txx.params['f'].value
# TCoeff_A = Modelfit_Txx.params['A'].value
# TCoeff_B = Modelfit_Txx.params['B'].value
# TCoeff = [TCoeff_a, TCoeff_b, TCoeff_c, TCoeff_d, TCoeff_e, TCoeff_f, TCoeff_A, TCoeff_B]

############################################################ y1 = f(x1, x2, T_pred)

X_train = np.concatenate((x_result[:, 0:2], T_pred.reshape(-1, 1)), axis = 1)
Y1_train = y_result[:, 0]
dY1_train = dydx_Ternary(X_train, Y1_train)

pf1 = PolynomialFeatures(degree = 4, include_bias = False)
MP1 = Pipeline([('pf', pf1), ('LR', LR1)])
MP1.fit(X_train, Y1_train)

Y1_pred = MP1.predict(X_train)
Rsquare = r2_score(Y1_train, Y1_pred)
deltaY1 = max(abs(Y1_train - Y1_pred))
mae = mean_absolute_error(Y1_train, Y1_pred)
dY1_pred = dydx_Ternary(X_train, Y1_pred)
dY1_test = Derivative_compare(dY1_train, dY1_pred)
error = Max_underestimation(Y1_train, Y1_pred)
print(Rsquare, deltaY1, mae, dY1_test)

# Y1_Coeff = MP1['LR'].coef_
# Y1_Intercept = MP1['LR'].intercept_

# Y1_Coeff = pd.DataFrame(Y1_Coeff)
# Y1_Coeff.to_excel('Y1_Coeff.xlsx', index = False)

############################################################ y2 = f(x1, x2, T_pred)

Y2_train = y_result[:, 1]
dY2_train = dydx_Ternary(X_train, Y2_train)

pf2 = PolynomialFeatures(degree = 4, include_bias = False)
MP2 = Pipeline([('pf', pf2), ('LR', LR2)])
MP2.fit(X_train, Y2_train)

Y2_pred = MP2.predict(X_train)
Rsquare = r2_score(Y2_train, Y2_pred)
deltaY2 = max(abs(Y2_train - Y2_pred))
mae = mean_absolute_error(Y2_train, Y2_pred)
dY2_pred = dydx_Ternary(X_train, Y2_pred)
dY2_test = Derivative_compare(dY2_train, dY2_pred)
print(Rsquare, deltaY2, mae, dY2_test)

# Y2_Coeff = MP2['LR'].coef_
# Y2_Intercept = MP2['LR'].intercept_

# Y2_Coeff = pd.DataFrame(Y2_Coeff)
# Y2_Coeff.to_excel('Y2_Coeff.xlsx', index = False)

############################################################# save

# Results = np.concatenate((x_result, y_result, T_result.reshape(-1, 1), T_pred.reshape(-1, 1), Y1_pred.reshape(-1, 1)), axis = 1)
# Results = pd.DataFrame(Results)
# Results.columns = ['x1', 'x2', 'x3', 'y1', 'y2', 'y3', 'T', 'T_pred', 'Y1_pred']
# Results.to_excel('THF_EA_NMP_Result.xlsx', index = False)



















# X_train = np.rint(X_train * 100)
# test_Y1 = np.hstack([X_train, Y1_train.reshape(-1, 1)])

# test1_x1 = test_Y1[test_Y1[:, 0] == 1, :]
# test1_x1 = test1_x1[test1_x1[:, 1].argsort()]
# test1_x2 = test_Y1[test_Y1[:, 1] == 1, :]
# test1_x2 = test1_x2[test1_x2[:, 0].argsort()]
          
# test_Y2 = np.hstack([X_train, Y1_pred.reshape(-1, 1)])

# test2_x1 = test_Y2[test_Y2[:, 0] == 1, :]
# test2_x1 = test2_x1[test2_x1[:, 1].argsort()]
# test2_x2 = test_Y2[test_Y2[:, 1] == 1, :]
# test2_x2 = test2_x2[test2_x2[:, 0].argsort()]



# X_train = x_result[:, 0]
# Y_train = y_result[:, 0]
# dY_train = dydx_Binary(x_result[:, 0], Y_train)

# model_yx = Model(One_One_Binary, independent_vars = ['x'])
# model_yx.set_param_hint('a', value = 400)
# model_yx.set_param_hint('b', value = 10000)
# model_yx.set_param_hint('A', value = 30)

# Modelfit_yx = model_yx.fit(Y_train, x = X_train)
# Y_pred = Modelfit_yx.eval(x = X_train)
# Rsquare = r2_score(Y_train, Y_pred)
# mae = mean_absolute_error(Y_train, Y_pred)
# deltaY = max(abs(Y_train - Y_pred.ravel()))
# dY_pred = dydx_Binary(X_train, Y_pred)
# dY_test = Derivative_compare(dY_train, dY_pred)
# print('Performance', Rsquare, deltaY, mae, dY_test)

# YCoeff_a = Modelfit_yx.params['a'].value
# YCoeff_b = Modelfit_yx.params['b'].value
# YCoeff_A = Modelfit_yx.params['A'].value
# YCoeff = [YCoeff_a, YCoeff_b, YCoeff_A]


# save = []
# XX = x_result[:, 0] * 100
# XX = np.rint(XX)
# for i in range(0, len(XX)):
#     if np.remainder(XX[i], 2) == 0:
#         save.append(i)

# Result = np.concatenate((x_result[:, 0].reshape(-1, 1), T_train.reshape(-1, 1), T_pred.reshape(-1, 1), Y_train.reshape(-1, 1), Y_pred.reshape(-1,1)), axis = 1)
# Result = Result[save, :]


save = []
XX = x_result * 100
XX = np.rint(XX)
for i in range(0, len(x_result)):
    if np.remainder(XX[i, 0], 2) == 0:
        if np.remainder(XX[i, 1], 2) == 0:
            save.append(i)

Result = np.concatenate((x_result, y_result, T_result.reshape(-1, 1), T_pred.reshape(-1, 1), Y1_pred.reshape(-1, 1), Y2_pred.reshape(-1, 1)), axis = 1)
Result = Result[save, :]



