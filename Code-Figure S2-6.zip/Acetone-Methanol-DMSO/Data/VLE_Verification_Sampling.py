# -*- coding: utf-8 -*-
"""
Created on Sat May 13 17:25:24 2023

@author: zhangx@mpi-magdeburg.mpg.de
"""

# %% import package

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.io
from thermo import UNIQUAC
from sklearn.base import clone
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.pipeline import Pipeline
from lmfit import Model

np.seterr(divide='ignore', invalid='ignore')

# %% initial data

Pressure = 101325

Comp_A = 'Acetone'
Antoine_A = {'A': 9.42448, 'B': 1312.253, 'C': -32.445}

Comp_B = 'Methanol'
Antoine_B = {'A': 10.20409, 'B': 1581.341, 'C': -33.5}

Comp_S = 'DMSO'
Antoine_S = {'A': 9.49107, 'B': 1807.002, 'C': -60.995}

# %% functions

def Antoine(Antoine_para, T):
    
    A = Antoine_para['A']
    B = Antoine_para['B']
    C = Antoine_para['C']
    Psat = np.power(10, A - B / (C + T))
    
    return Psat

def Tb(Antoine_para, P):
        
    A = Antoine_para['A']
    B = Antoine_para['B']
    C = Antoine_para['C']
    Boiling_point = B / (A - np.log10(P)) - C
    
    return Boiling_point

def Binary_Txy_UNIQUAC_AB(Antoine_para, P):
    
    x_result = []
    y_result = []
    T_result = []
    
    Tb_light = Tb(Antoine_para[0], P)
    Tb_heavy = Tb(Antoine_para[1], P)
    Interval = int((Tb_heavy - Tb_light) * 100)
    T_start = Tb_heavy    
    
    rs = [2.5735, 1.4311]
    qs = [2.296, 1.432]
    tau_bs = [[0, -225.153], [52.7705, 0]]    
     
    for i in range(0, 101):
        
        x = [i*0.01, 1-i*0.01]
        x_result.append(x)
        
        if i == 0:
            y_result.append([0, 1])
            T_result.append(Tb_heavy)
        elif i == 100:
            y_result.append([1, 0])
            T_result.append(Tb_light)
        else:        
            T_guess = T_start + 1    
            for j in range(0, Interval):       
                gama = UNIQUAC(T = T_guess, xs = x, rs = rs, qs = qs, tau_bs = tau_bs)
                Psat_A = Antoine(Antoine_para[0], T_guess)
                Psat_B = Antoine(Antoine_para[1], T_guess)
                P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                if P_test > P:
                    T_guess -= 0.1
                elif P_test < P:
                    for k in range(0, 100):
                        T_guess += 0.001
                        gama = UNIQUAC(T = T_guess, xs = x, rs = rs, qs = qs, tau_bs = tau_bs)
                        Psat_A = Antoine(Antoine_para[0], T_guess)
                        Psat_B = Antoine(Antoine_para[1], T_guess)
                        P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                        if P_test >= P or k == 99:
                            y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                            y_result.append(y)
                            T_result.append(T_guess)
                            break
                    T_start = T_guess
                    break
                elif P_test == P:
                    y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                    y_result.append(y)
                    T_result.append(T_guess)
                    T_start = T_guess
                    break
    
    x_result = np.array(x_result)
    y_result = np.array(y_result)
    T_result = np.array(T_result)
    
    return x_result, y_result, T_result

def Binary_Txy_UNIQUAC_AS(Antoine_para, P):
    
    x_result = []
    y_result = []
    T_result = []
    
    Tb_light = Tb(Antoine_para[0], P)
    Tb_heavy = Tb(Antoine_para[1], P)
    Interval = int((Tb_heavy - Tb_light) * 100)
    T_start = Tb_heavy    

    rs = [2.5735, 2.8266]    
    qs = [2.296, 2.472]
    tau_bs = [[0, -62.9317], [-20.3857, 0]]    
     
    for i in range(0, 101):
        
        x = [i*0.01, 1-i*0.01]
        x_result.append(x)
        
        if i == 0:
            y_result.append([0, 1])
            T_result.append(Tb_heavy)
        elif i == 100:
            y_result.append([1, 0])
            T_result.append(Tb_light)
        else:        
            T_guess = T_start + 1    
            for j in range(0, Interval):       
                gama = UNIQUAC(T = T_guess, xs = x, rs = rs, qs = qs, tau_bs = tau_bs)
                Psat_A = Antoine(Antoine_para[0], T_guess)
                Psat_B = Antoine(Antoine_para[1], T_guess)
                P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                if P_test > P:
                    T_guess -= 0.1
                elif P_test < P:
                    for k in range(0, 100):
                        T_guess += 0.001
                        gama = UNIQUAC(T = T_guess, xs = x, rs = rs, qs = qs, tau_bs = tau_bs)
                        Psat_A = Antoine(Antoine_para[0], T_guess)
                        Psat_B = Antoine(Antoine_para[1], T_guess)
                        P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                        if P_test >= P or k == 99:
                            y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                            y_result.append(y)
                            T_result.append(T_guess)
                            break
                    T_start = T_guess
                    break
                elif P_test == P:
                    y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                    y_result.append(y)
                    T_result.append(T_guess)
                    T_start = T_guess
                    break
    
    x_result = np.array(x_result)
    y_result = np.array(y_result)
    T_result = np.array(T_result)
    
    return x_result, y_result, T_result

def Binary_Txy_UNIQUAC_BS(Antoine_para, P):
    
    x_result = []
    y_result = []
    T_result = []
    
    Tb_light = Tb(Antoine_para[0], P)
    Tb_heavy = Tb(Antoine_para[1], P)
    Interval = int((Tb_heavy - Tb_light) * 100)
    T_start = Tb_heavy    

    rs = [1.4311, 2.8266]
    qs = [1.432, 2.472]
    tau_bs = [[0, 129.362], [23.4854, 0]]
    
    for i in range(0, 101):
        
        x = [i*0.01, 1-i*0.01]
        x_result.append(x)
        
        if i == 0:
            y_result.append([0, 1])
            T_result.append(Tb_heavy)
        elif i == 100:
            y_result.append([1, 0])
            T_result.append(Tb_light)
        else:        
            T_guess = T_start + 1    
            for j in range(0, Interval):       
                gama = UNIQUAC(T = T_guess, xs = x, rs = rs, qs = qs, tau_bs = tau_bs)
                Psat_A = Antoine(Antoine_para[0], T_guess)
                Psat_B = Antoine(Antoine_para[1], T_guess)
                P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                if P_test > P:
                    T_guess -= 0.1
                elif P_test < P:
                    for k in range(0, 100):
                        T_guess += 0.001
                        gama = UNIQUAC(T = T_guess, xs = x, rs = rs, qs = qs, tau_bs = tau_bs)
                        Psat_A = Antoine(Antoine_para[0], T_guess)
                        Psat_B = Antoine(Antoine_para[1], T_guess)
                        P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B
                        if P_test >= P or k == 99:
                            y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                            y_result.append(y)
                            T_result.append(T_guess)
                            break
                    T_start = T_guess
                    break
                elif P_test == P:
                    y = [gama.gammas()[0]* x[0] * Psat_A / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test]
                    y_result.append(y)
                    T_result.append(T_guess)
                    T_start = T_guess
                    break
    
    x_result = np.array(x_result)
    y_result = np.array(y_result)
    T_result = np.array(T_result)
    
    return x_result, y_result, T_result

def Ternary_Txy_UNIQUAC(Antoine_para, P):
    
    x_result = []
    y_result = []
    T_result = []

    Tb_light = Tb(Antoine_para[0], P)
    Tb_heavy = Tb(Antoine_para[2], P)
    Interval = int((Tb_heavy - Tb_light) * 500)

    rs = [2.5735, 1.4311, 2.8266]    
    qs = [2.296, 1.432, 2.472]
    tau_bs = [[0, -225.153, -62.9317], [52.7705, 0, 129.362], [-20.3857, 23.4854, 0]]
    
    for i in range(1, 100):
        T_start = Tb_heavy
        for j in range(1, i):
            
            x = [j*0.01, (i-j)*0.01, 1-i*0.01]
            x_result.append([int(j), int(i-j), int(100-i)])
            
            T_guess = T_start + 10
            for z in range(0, Interval):
                gama = UNIQUAC(T = T_guess, xs = x, rs = rs, qs = qs, tau_bs = tau_bs)                   
                Psat_A = Antoine(Antoine_para[0], T_guess)
                Psat_B = Antoine(Antoine_para[1], T_guess)
                Psat_C = Antoine(Antoine_para[2], T_guess)
                P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B + gama.gammas()[2] * x[2] * Psat_C
                if P_test > P:
                    T_guess -= 0.1
                elif P_test < P:
                    for k in range(0, 100):
                        T_guess += 0.001
                        gama = UNIQUAC(T = T_guess, xs = x, rs = rs, qs = qs, tau_bs = tau_bs)
                        Psat_A = Antoine(Antoine_para[0], T_guess)
                        Psat_B = Antoine(Antoine_para[1], T_guess)
                        Psat_C = Antoine(Antoine_para[2], T_guess)
                        P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B + gama.gammas()[2] * x[2] * Psat_C
                        if P_test >= P or k == 99:
                            y = [gama.gammas()[0]* x[0] * Psat_A / P_test, gama.gammas()[1]* x[1] * Psat_B / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test - gama.gammas()[1]* x[1] * Psat_B / P_test]
                            y_result.append(y)
                            T_result.append(T_guess)
                            break
                    T_start = T_guess
                    break
                elif P_test == P:
                    y = [gama.gammas()[0]* x[0] * Psat_A / P_test, gama.gammas()[1]* x[1] * Psat_B / P_test, 1 - gama.gammas()[0]* x[0] * Psat_A / P_test - gama.gammas()[1]* x[1] * Psat_B / P_test]
                    y_result.append(y)
                    T_result.append(T_guess)
                    T_start = T_guess
                    break
                
    x_result = np.array(x_result)
    y_result = np.array(y_result)
    T_result = np.array(T_result)    
    
    x_result_ab, y_result_ab, T_result_ab = Binary_Txy_UNIQUAC_AB([Antoine_para[0], Antoine_para[1]], P)
    x_result_as, y_result_as, T_result_as = Binary_Txy_UNIQUAC_AS([Antoine_para[0], Antoine_para[2]], P)
    x_result_bs, y_result_bs, T_result_bs = Binary_Txy_UNIQUAC_BS([Antoine_para[1], Antoine_para[2]], P)
    
    x_result_as = np.delete(x_result_as, len(x_result_as)-1, 0)
    y_result_as = np.delete(y_result_as, len(y_result_as)-1, 0)
    T_result_as = np.delete(T_result_as, len(T_result_as)-1, 0)    

    x_result_bs = np.delete(x_result_bs, len(x_result_bs)-1, 0)
    y_result_bs = np.delete(y_result_bs, len(y_result_bs)-1, 0)
    T_result_bs = np.delete(T_result_bs, len(T_result_bs)-1, 0)       

    x_result_bs = np.delete(x_result_bs, 0, 0)
    y_result_bs = np.delete(y_result_bs, 0, 0)
    T_result_bs = np.delete(T_result_bs, 0, 0)    
        
    x_result_ab = np.c_[x_result_ab, np.zeros(len(x_result_ab))]
    y_result_ab = np.c_[y_result_ab, np.zeros(len(y_result_ab))]   
    x_result_as = np.c_[x_result_as[:, 0], np.zeros(len(x_result_as)), x_result_as[:, 1]]
    y_result_as = np.c_[y_result_as[:, 0], np.zeros(len(y_result_as)), y_result_as[:, 1]]
    x_result_bs = np.c_[np.zeros(len(x_result_bs)), x_result_bs]
    y_result_bs = np.c_[np.zeros(len(y_result_bs)), y_result_bs]
    
    x_result = np.concatenate((x_result, x_result_ab, x_result_as, x_result_bs), axis = 0)
    y_result = np.concatenate((y_result, y_result_ab, y_result_as, y_result_bs), axis = 0)
    T_result = np.concatenate((T_result, T_result_ab, T_result_as, T_result_bs))
    
    return x_result, y_result, T_result

# %% functions

LR1 = LinearRegression()
LR2 = clone(LR1)

def dTdx_Binary(x, T):
    
    T_derivative = []
    for i in range(0, len(T)-1):
        if T[i+1] - T[i] < 0:
            T_derivative.append(1)
        else:
            T_derivative.append(0)          
    T_derivative = np.array(T_derivative)
    
    return T_derivative

def dydx_Binary(x, y):
    
    y_derivative = []
    for i in range(0, len(y)-1):
        if y[i+1] - y[i] > 0:
            y_derivative.append(1)
        else:
            y_derivative.append(0)
    y_derivative = np.array(y_derivative)   
    
    return y_derivative

def dTdx_Ternary(X_train, T_train):
    
    X_train = np.rint(X_train * 100)
    test_T = np.hstack([X_train, T_train.reshape(-1, 1)])
    dTdx1 = []
    dTdx2 = []
    for i in range(1, 100):
        test_x1 = test_T[test_T[:, 0] == i, :]
        test_x1 = test_x1[test_x1[:, 1].argsort()]    
        test_x2 = test_T[test_T[:, 1] == i, :]
        test_x2 = test_x2[test_x2[:, 0].argsort()]
        for j in range(0, 100 - i):
            if test_x1[j + 1, 2] - test_x1[j, 2] <= 0:
                dTdx1.append(1)
            else:
                dTdx1.append(0)
            if test_x2[j + 1, 2] - test_x2[j, 2] <= 0:
                dTdx2.append(1)
            else:
                dTdx2.append(0)
    
    return dTdx1 + dTdx2

def dydx_Ternary(X_train, Y_train):
    
    X_train = np.rint(X_train * 100)
    test_Y = np.hstack([X_train, Y_train.reshape(-1, 1)])
    dydx1 = []
    dydx2 = []
    for i in range(1, 100):
        test_x1 = test_Y[test_Y[:, 0] == i, :]
        test_x1 = test_x1[test_x1[:, 1].argsort()]
        test_x2 = test_Y[test_Y[:, 1] == i, :]
        test_x2 = test_x2[test_x2[:, 0].argsort()]
        for j in range(0, 100 - i):
            if test_x1[j + 1, 2] - test_x1[j, 2] <= 0:
                dydx1.append(1)
            else:
                dydx1.append(0)
            if test_x2[j + 1, 2] - test_x2[j, 2] >= 0:
                dydx2.append(1)
            else:
                dydx2.append(0)            
    
    return dydx1 + dydx2

def Max_underestimation(Y_train, Y_pred):
    
    Y_train_data = []
    Y_pred_data = []
    for i in range(len(Y_train)):
        if Y_train[i] >= 0.95:
            Y_train_data.append(Y_train[i])
            Y_pred_data.append(Y_pred[i])
    Y_train_data = np.array(Y_train_data)
    Y_pred_data = np.array(Y_pred_data)
    return max(Y_train_data - Y_pred_data)

def Derivative_compare(train, pred):
    
    count = 0
    for i in range(len(train)):
        if int(train[i]) == int(pred[i]):
            count += 1
            
    return count / len(train)
def One_One_Binary(x, a, b, A):
    return (a + b*x) / (A*x + 1)

def Two_One_Binary(x, a, b, c, A):
    return (a + b*x + c*x*x) / (A*x + 1)

def One_One_Ternary(x, y, a, b, c, A, B):
    return (a + b*x + c*y) / (A*x + B*y + 1)

def Two_One_Ternary(x, y, a, b, c, d, e, f, A, B):
    return (a + b*x + c*y + d*x*x + e*x*y + f*y*y) / (A*x + B*y + 1)

def Three_One_Ternary(x, y, a, b, c, d, e, f, g, h, i, j, A, B):
    return (a + b*x + c*y + d*x*x + e*x*y + f*y*y + g*x*x*x + h*x*x*y + i*x*y*y + j*y*y*y) / (A*x + B*y + 1)

def Two_Two_Ternary(x, y, a, b, c, d, e, f, A, B, C, D, E):
    return (a + b*x + c*y + d*x*x + e*x*y + f*y*y) / (A*x*x + B*x*y + C*y*y + D*x + E*y + 1)

def Three_Two_Ternary(x, y, a, b, c, d, e, f, g, h, i, j, A, B, C, D, E):
    return (a + b*x + c*y + d*x*x + e*x*y + f*y*y + g*x*x*x + h*x*x*y + i*x*y*y + j*y*y*y) / (A*x*x + B*x*y + C*y*y + D*x + E*y + 1)

# %% Binary Acetone + Methanol: from Aspen 10.1021/acs.iecr.8b00711

# Antoine_1 = [Antoine_A, Antoine_B]
# x_result, y_result, T_result = Binary_Txy_UNIQUAC_AB(Antoine_1, Pressure)

# x_aspen = np.array([0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1])
# y_aspen = np.array([0,0.1975626,0.3319688,0.4319681,0.5128177,0.5836666,0.6508498,0.7196378,0.7954794,0.8853562,1])
# T_aspen = np.array([337.6848,334.6396,332.5515,331.0835,330.0342,329.2844,328.77,328.4691,328.3998,328.6274,329.2866])

# plt.plot(x_aspen, y_aspen, '-r')
# plt.plot(x_result[:, 0], y_result[:, 0], '-b')
# plt.legend(['Aspen', 'Python'])
# plt.show()

# plt.plot(x_aspen, T_aspen, '-r')
# plt.plot(x_result[:, 0], T_result, '-b')
# plt.legend(['Aspen', 'Python'])
# plt.show()

# %% Binary Methanol + DMSO: from Aspen 10.1021/acs.iecr.8b00711

# Antoine_2 = [Antoine_B, Antoine_S]
# x_result, y_result, T_result = Binary_Txy_UNIQUAC_BS(Antoine_2, Pressure)

# x_aspen = np.array([0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1])
# y_aspen = np.array([0,0.7269055,0.8879621,0.9466464,0.9730642,0.9862443,0.9931361,0.9967782,0.9986653,0.9995918,1])
# T_aspen = np.array([463.8927,422.6726,400.5488,385.4368,373.9147,364.6173,356.9012,350.4447,345.0987,340.8267,337.6848])

# plt.plot(x_aspen, y_aspen, '-r')
# plt.plot(x_result[:, 0], y_result[:, 0], '-b')
# plt.legend(['Aspen', 'Python'])
# plt.show()

# plt.plot(x_aspen, T_aspen, '-r')
# plt.plot(x_result[:, 0], T_result, '-b')
# plt.legend(['Aspen', 'Python'])
# plt.show()

# %% Methanol + DMSO sampling & fitting

# Antoine_b = [Antoine_B, Antoine_S]
# x_result, y_result, T_result = Binary_Txy_UNIQUAC_BS(Antoine_b, Pressure)

# X_train = x_result[:, 0]
# T_train = T_result
# dT_train = dTdx_Binary(X_train, T_train)

# model_Tx = Model(One_One_Binary, independent_vars = ['x'])
# model_Tx.set_param_hint('a', value = 471)
# model_Tx.set_param_hint('b', value = 800)
# model_Tx.set_param_hint('A', value = 2)

# Modelfit_Tx = model_Tx.fit(T_train, x = X_train)
# T_pred = Modelfit_Tx.eval(x = X_train)
# Rsquare = r2_score(T_train, T_pred)
# mae = mean_absolute_error(T_train, T_pred)
# deltaT = max(abs(T_train - T_pred.ravel()))
# dT_pred = dTdx_Binary(X_train, T_pred)
# dT_test = Derivative_compare(dT_train, dT_pred)
# print('Performance', Rsquare, deltaT, mae, dT_test)

# TCoeff_a = Modelfit_Tx.params['a'].value
# TCoeff_b = Modelfit_Tx.params['b'].value
# TCoeff_A = Modelfit_Tx.params['A'].value
# TCoeff = [TCoeff_a, TCoeff_b, TCoeff_A]

# plt.plot(X_train, T_train, '-r', label = 'train')
# plt.plot(X_train, T_pred, '-b', label = 'prediction')
# plt.legend(['train', 'prediction'])
# plt.show()

############################################################ y = f(x1, T_pred) fitting

# X_train = np.concatenate((x_result[:, 0].reshape(-1, 1), T_pred.reshape(-1, 1)), axis = 1)
# Y_train = y_result[:, 0]
# dY_train = dydx_Binary(x_result[:, 0], Y_train)

# pf = PolynomialFeatures(degree = 3, include_bias = False)
# MP = Pipeline([('pf', pf), ('LR', LR1)])
# MP.fit(X_train, Y_train)

# Y_pred = MP.predict(X_train)
# Rsquare = r2_score(Y_train, Y_pred)
# deltaY = max(abs(Y_train - Y_pred))
# mae = mean_absolute_error(Y_train, Y_pred)
# dY_pred = dydx_Binary(x_result[:, 0], Y_pred)
# dY_test = Derivative_compare(dY_train, dY_pred)
# print(Rsquare, deltaY, mae, dY_test)

# Y_Coeff = MP['LR'].coef_
# Y_Intercept = MP['LR'].intercept_

# Y_Coeff = pd.DataFrame(Y_Coeff)
# Y_Coeff.to_excel('Y_Coeff.xlsx', index = False)

# plt.plot(x_result[:, 0], Y_train, '-r')
# plt.plot(x_result[:, 0], Y_pred, '-b')
# plt.legend(['train', 'prediction'])
# plt.show()

############################################################# save 

# Results = np.concatenate((x_result, y_result, T_result.reshape(-1, 1), T_pred.reshape(-1, 1), Y_pred.reshape(-1, 1)), axis = 1)
# Results = pd.DataFrame(Results)
# Results.columns = ['x1', 'x2', 'y1', 'y2', 'T', 'T_pred', 'Y_pred']

# Output = Results
# Output.to_excel('Me_DMSO_Result.xlsx', index = False)

# %% Ternary sampling & fitting

# Antoine_t = [Antoine_A, Antoine_B, Antoine_S]
# x_result, y_result, T_result = Ternary_Txy_UNIQUAC(Antoine_t, Pressure)

# Output = {'x': x_result, 'y': y_result, 'T': T_result}
# scipy.io.savemat('Ternary_VLE.mat', Output)

VLE = scipy.io.loadmat('Ternary_VLE.mat')
x_result = VLE['x']
y_result = VLE['y']
T_result = VLE['T']

X_train = x_result[:, 0:2]
X1_train = x_result[:, 0]
X2_train = x_result[:, 1]
T_train = T_result.ravel()
dT_train = dTdx_Ternary(x_result[:, 0:2], T_train)

model_Txx = Model(Two_One_Ternary, independent_vars = ['x', 'y'])
model_Txx.set_param_hint('a', value = 400)
model_Txx.set_param_hint('b', value = 10000)
model_Txx.set_param_hint('c', value = 10000)
model_Txx.set_param_hint('d', value = -400)
model_Txx.set_param_hint('e', value = -2000)
model_Txx.set_param_hint('f', value = -1000)
model_Txx.set_param_hint('A', value = 30)
model_Txx.set_param_hint('B', value = 30)

Modelfit_Txx = model_Txx.fit(T_train, x = X1_train, y = X2_train)
T_pred = Modelfit_Txx.eval(x = X1_train, y = X2_train).ravel()
Diff_T = T_pred - T_train
Rsquare = r2_score(T_train, T_pred)
mae = mean_absolute_error(T_train, T_pred)
deltaT = max(abs(T_pred - T_train))
dT_pred = dTdx_Ternary(x_result[:, 0:2], T_pred)
dT_test = Derivative_compare(dT_train, dT_pred)
print(Rsquare, deltaT, mae, dT_test)

# TCoeff_a = Modelfit_Txx.params['a'].value
# TCoeff_b = Modelfit_Txx.params['b'].value
# TCoeff_c = Modelfit_Txx.params['c'].value
# TCoeff_d = Modelfit_Txx.params['d'].value
# TCoeff_e = Modelfit_Txx.params['e'].value
# TCoeff_f = Modelfit_Txx.params['f'].value
# TCoeff_A = Modelfit_Txx.params['A'].value
# TCoeff_B = Modelfit_Txx.params['B'].value
# TCoeff = [TCoeff_a, TCoeff_b, TCoeff_c, TCoeff_d, TCoeff_e, TCoeff_f, TCoeff_A, TCoeff_B]

########################################################### y1 = f(x1, x2, T_pred)

X_train = np.concatenate((x_result[:, 0:2], T_pred.reshape(-1, 1)), axis = 1)
Y1_train = y_result[:, 0]
dY1_train = dydx_Ternary(x_result[:, 0:2], Y1_train)

pf1 = PolynomialFeatures(degree = 4, include_bias = False)
MP1 = Pipeline([('pf', pf1), ('LR', LR1)])
MP1.fit(X_train, Y1_train)

Y1_pred = MP1.predict(X_train)
Rsquare = r2_score(Y1_train, Y1_pred)
deltaY1 = max(abs(Y1_train - Y1_pred))
mae = mean_absolute_error(Y1_train, Y1_pred)
dY1_pred = dydx_Ternary(x_result[:, 0:2], Y1_pred)
dY1_test = Derivative_compare(dY1_train, dY1_pred)
error = Max_underestimation(Y1_train, Y1_pred)
print(Rsquare, deltaY1, mae, dY1_test)

# Y1_Coeff = MP1['LR'].coef_
# Y1_Intercept = MP1['LR'].intercept_

# Y1_Coeff = pd.DataFrame(Y1_Coeff)
# Y1_Coeff.to_excel('Y1_Coeff.xlsx', index = False)

############################################################ y2 = f(x1, x2, T_pred)

Y2_train = y_result[:, 1]
dY2_train = dydx_Ternary(x_result[:, 0:2], Y2_train)

pf2 = PolynomialFeatures(degree = 4, include_bias = False)
MP2 = Pipeline([('pf', pf2), ('LR', LR2)])
MP2.fit(X_train, Y2_train)

Y2_pred = MP2.predict(X_train)
Rsquare = r2_score(Y2_train, Y2_pred)
deltaY2 = max(abs(Y2_train - Y2_pred))
mae = mean_absolute_error(Y2_train, Y2_pred)
dY2_pred = dydx_Ternary(x_result[:, 0:2], Y2_pred)
dY2_test = Derivative_compare(dY2_train, dY2_pred)
print(Rsquare, deltaY2, mae, dY2_test)

# Y2_Coeff = MP2['LR'].coef_
# Y2_Intercept = MP2['LR'].intercept_

# Y2_Coeff = pd.DataFrame(Y2_Coeff)
# Y2_Coeff.to_excel('Y2_Coeff.xlsx', index = False)

############################################################# save

# Results = np.concatenate((x_result, y_result, T_result.reshape(-1, 1), T_pred.reshape(-1, 1), Y1_pred.reshape(-1, 1)), axis = 1)
# Results = pd.DataFrame(Results)
# Results.columns = ['x1', 'x2', 'x3', 'y1', 'y2', 'y3', 'T', 'T_pred', 'Y1_pred']
# Results.to_excel('Ac_Me_DMSO_Result.xlsx', index = False)


# Antoine_para = [Antoine_A, Antoine_B, Antoine_S]

# rs = [2.5735, 1.4311, 2.8266]    
# qs = [2.296, 1.432, 2.472]
# tau_bs = [[0, -225.153, -62.9317], [52.7705, 0, 129.362], [-20.3857, 23.4854, 0]]


# T_guess = 342.102
# x1 = 0.591174
# x2 = 0.00135685
# x = [x1, x2, 1-x1-x2]

# gama = UNIQUAC(T = T_guess, xs = x, rs = rs, qs = qs, tau_bs = tau_bs)     

# Psat_A = Antoine(Antoine_para[0], T_guess)
# Psat_B = Antoine(Antoine_para[1], T_guess)
# Psat_C = Antoine(Antoine_para[2], T_guess)
# P_test = gama.gammas()[0] * x[0] * Psat_A + gama.gammas()[1] * x[1] * Psat_B + gama.gammas()[2] * x[2] * Psat_C

# print(P_test - 101325)

# print(gama.gammas()[0] * x[0] * Psat_A / P_test)


# save = []
# XX = x_result[:, 0] * 100
# XX = np.rint(XX)
# for i in range(0, len(XX)):
#     if np.remainder(XX[i], 2) == 0:
#         save.append(i)

# Result = np.concatenate((x_result[:, 0].reshape(-1, 1), T_train.reshape(-1, 1), T_pred.reshape(-1, 1), Y_train.reshape(-1, 1), Y_pred.reshape(-1,1)), axis = 1)
# Result = Result[save, :]

save = []
XX = x_result * 100
XX = np.rint(XX)
for i in range(0, len(x_result)):
    if np.remainder(XX[i, 0], 2) == 0:
        if np.remainder(XX[i, 1], 2) == 0:
            save.append(i)

Result = np.concatenate((x_result, y_result, T_result.reshape(-1, 1), T_pred.reshape(-1, 1), Y1_pred.reshape(-1, 1), Y2_pred.reshape(-1, 1)), axis = 1)
Result = Result[save, :]




















