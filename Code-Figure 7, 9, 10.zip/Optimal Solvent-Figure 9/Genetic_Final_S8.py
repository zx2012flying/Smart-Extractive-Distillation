# -*- coding: utf-8 -*-
"""
Created on Tue Jun 13 11:47:01 2023

@author: sahil
"""
import os
import time
from win32com.client import GetObject, Dispatch
import numpy as np
import random
from pyDOE import lhs
import pandas as pd
#%%
np.random.seed(10)
random.seed(10)
#%%
#python_aspen_interface functions
class Aspen_Plus_Interface():
    def __init__(self):
        self.Application = Dispatch("Apwn.Document.38.0")
        # {"V10.0": "36.0", V11.0": "37.0", V12.0": "38.0"}
        print(self.Application)

    def load_bkp(self, bkp_file, visible_state=0, dialog_state=0):
        """
        Load a process via bkp file
        :param bkp_file: location of the Aspen Plus file
        :param visible_state: Aspen Plus user interface, 0 is invisible and 1 is visible
        :param dialog_state: Aspen Plus dialogs, 0 is not to suppress and 1 is to suppress
        """
        self.Application.InitFromArchive2(os.path.abspath(bkp_file))
        self.Application.Visible = visible_state
        self.Application.SuppressDialogs = dialog_state

    def re_initialization(self):
        # initial the chemical process in Aspen Plus
        self.Application.Reinit()

    def run_simulation(self):
        # run the process simulation
        self.Application.Engine.Run()

    def check_run_completion(self, time_limit=60):
        # check whether the simulation completed
        times = 0
        while self.Application.Engine.IsRunning == 1:
            time.sleep(1)
            times += 1
            if times >= time_limit:
                print("Violate time limitation")
                self.Application.Engine.Stop
                break

    def check_convergency(self):
        # check the simulation convergency by detecting errors in the history file
        runID = self.Application.Tree.FindNode("\Data\Results Summary\Run-Status\Output\RUNID").Value
        his_file = "C:/Users/sahil/Desktop/Aspen-Python/Solvent 8/" + runID + ".his"
        with open(his_file, "r") as f:
            hasERROR = np.any(np.array([line.find("ERROR") for line in f.readlines()]) >= 0)
        return hasERROR

    def close_bkp(self):
        # close the Aspen Plus file
        self.Application.Quit()

    def collect_stream(self):
        # colloct all streams involved in the process
        streams = []
        node = self.Application.Tree.FindNode(r"\Data\Streams")
        for item in node.Elements:
            streams.append(item.Name)
        return tuple(streams)

    def collect_block(self):
        # colloct all blocks involved in the process
        blocks = []
        node = self.Application.Tree.FindNode(r"\Data\Blocks")
        for item in node.Elements:
            blocks.append(item.Name)
        return tuple(blocks)


def KillAspen():
    # kill the Aspen Plus
    WMI = GetObject("winmgmts:")
    for p in WMI.ExecQuery("select * from Win32_Process where Name='AspenPlus.exe'"):
        os.system("taskkill /pid " + str(p.ProcessId))


def SequenceWithEndPoint(start, stop, step):
    # generate evenly spaced values containing the end point
    return np.arange(start, stop + step, step)


def ListValue2Str(alist):
    # convert a list of mixed variables into string formats
    return list(map(str, alist))

#%%

#genetic algorithm
# load Aspen Plus file
Aspen_Plus = Aspen_Plus_Interface()
Aspen_Plus.load_bkp(r"C:/Users/sahil/Desktop/Aspen-Python/Solvent 8/Sol_8.bkp", 0, 1)

def foo(NT,R,StoF,SNT,SR,ff,fs,sff,DIS,SDIS):
    Aspen_Plus.re_initialization()
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\NSTAGE").Value = np.rint(NT)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Input\NSTAGE").Value = np.rint(SNT)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\BASIS_RR").Value = round(R,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Input\BASIS_RR").Value = round(SR,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\SOLVENT\Input\TOTFLOW\MIXED").Value = round(StoF * FeedRate,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\BASIS_D").Value = round(DIS,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Input\BASIS_D").Value = round(SDIS,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\FEED_STAGE\FEED").Value = np.rint(ff * NT)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\FEED_STAGE\SOLVENT").Value = np.rint(fs * NT)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Input\FEED_STAGE\BOT").Value = np.rint(sff * SNT)

    # run the process simulation
    Aspen_Plus.run_simulation()
    Aspen_Plus.check_run_completion()
    hasERROR = Aspen_Plus.check_convergency()
    
    # collect results
    xD_Eb = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\DIS\Output\MOLEFRAC\MIXED\EB").Value
    SxD_ST = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\SDIS\Output\MOLEFRAC\MIXED\ST").Value
    Di_Eb = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\DIS\Output\MOLEFLOW\MIXED\EB").Value
    Bi_ST = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\BOT\Output\MOLEFLOW\MIXED\ST").Value
    SDi_ST = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\SDIS\Output\MOLEFLOW\MIXED\ST").Value
    SDi_Solvent = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\SDIS\Output\MOLEFLOW\MIXED\S8").Value
    
    if xD_Eb>=0.99 and SxD_ST>=0.99 and Di_Eb>=495 and SDi_ST>=0.99*Bi_ST and hasERROR==False:   
        QR = 3600*Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Output\REB_DUTY").Value
        SQR = 3600*Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Output\REB_DUTY").Value
        QC = -1*3600*Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Output\COND_DUTY").Value
        SQCC = -1*3600*Aspen_Plus.Application.Tree.FindNode("\Data\Blocks\SQCC\Output\QCALC").Value
        
        SQC = -1*3600*Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Output\COND_DUTY").Value
        CED = 56910*((QR/(100*30*2249.28))**0.71)  + 56910*((QC/(100*30.26*2249.28))**0.71)+ 81300*((((4+0.5*NT)*(((4+0.5*NT)/10)**1.5))/20)**0.81) + 2439*NT* (((((4+0.5*NT)/10)**1.5)/2.13)**0.8)
        CSR = 56910*((SQR/(100*30*2249.28))**0.71)  + 56910*((SQC/(100*30.26*2249.28))**0.71)+ 81300*((((4+0.5*SNT)*(((4+0.5*SNT)/10)**1.5))/20)**0.81) + 2439*SNT* (((((4+0.5*SNT)/10)**1.5)/2.13)**0.8)
        CHE = 56910*((SQCC/(100*30.26*2249.28))**0.71)
        
        OBJ = 0.064 * (QR + SQR) + 0.002832 * (QC + SQC) + 1.127 * (CED + CSR) + 0.002832 * SQCC + 1.127 * CHE
        fitness_value = OBJ

        return fitness_value

def fitness(NT,R,StoF,SNT,SR,ff,fs,sff,DIS,SDIS):
    ans = foo(NT,R,StoF,SNT,SR,ff,fs,sff,DIS,SDIS)
    if ans is not None:
      return(8481900/ans)
  
def crossover(bestsolution):
    parent1 = np.array(bestsolution[0][1])
    parent2 = np.array(bestsolution[1][1])
    noOFCol = len(parent1)
    child1 = np.zeros(noOFCol)
 
    #crossoversite
    crossSite = random.randrange(1,noOFCol-1)
    for i in range(noOFCol):
        if i>=crossSite:
            child1[i] = parent2[i]
        else:
            child1[i] = parent1[i]
    return child1

def mutation(new_generations,child,num,probability):
    new_gen = []
    for _ in range((new_generations)):
        for _ in range(num):
            index = random.randrange(len(list(child)))
            a = np.random.random()
            if a>probability:
                child[index] = child[index]
            else:
                child[index] = child[index]*np.random.uniform(0.99,1.01)
        new_gen.append(tuple(child))
    return new_gen

#%%
#generate solutions/samples  using lhs
number_of_generations = 100
new_generation = 20
num_initial_samples = 200  #population used in lhs
GAMS_best = 8481900
NT =   list(np.linspace(38,46,10))         # number of stages in 1st column
R =    list(np.linspace(0.54,1.34,10))       # reflux ratio in 1st column
StoF = list(np.linspace(1.31,2.21,10))       # solvent to feed ratio
SNT =  list(np.linspace(13,19,7))          # number of trays in 2nd column
SR =   list(np.linspace(0.05,0.15,10))     # reflux ratio of 2nd column
ff =   list(np.linspace(0.35,0.45,10))     # feed stage of feed mixture in 1st column
fs =   list(np.linspace(0.05,0.15,10))     # feed stage of solvent
sff =  list(np.linspace(0.4,0.6,10))     # feed stage of 2nd column
DIS =  list(np.linspace(495,505,10))        # Distillate of 1st column
SDIS = list(np.linspace(490,500,10))       # Distillate of 2nd column
# Define the inputs and their possible values
inputs = {
    'NT': NT,'R' : R, 'StoF' : StoF, 'SNT': SNT, 'SR' : SR,
    'ff' : ff, 'fs' : fs, 'sff': sff,'DIS' : DIS, 'SDIS': SDIS
}


#genetic algorithm
# Step:1 Generate the Latin Hypercube sample for initial population
lhs_sample = lhs(len(inputs), samples=num_initial_samples)

# Create the initial population using exact values of each input
solutions = []
rankedsolutions = []
for i in range(num_initial_samples):
    sample = tuple([inputs[key][int(lhs_sample[i][j] * len(inputs[key]))] for j, key in enumerate(inputs.keys())])
    solutions.append(sample)
# calculating fitness
generation_wise_best_solution = []
rankedsolutions = []
total_iterations = []
objective = []
FeedRate = 1000

# =============================================================================
# solutions.append((42.16554397807052, 1.0305919328610735, 1.2457052995978617, 18.161506341503525, 0.14304969069361093, 0.4190361183725892, 0.0835528963498245, 0.43865574565835624, 500.95201529917097, 496.7338048745352))
# solutions.append((42.11944389482743, 1.0452404399548683, 1.2361507996655139, 18.161506341503525, 0.1415992519162365, 0.4235808829078463, 0.08315705465788419, 0.43615549841838, 502.67894419449107, 493.6508279387554))
# =============================================================================
print("Start simulation ...")
for i in range(number_of_generations):
    TimeStart = time.time()
    new_gen = []
    for s in solutions:
        print(solutions.index(s))
        a = fitness(s[0],s[1],s[2],s[3],s[4],s[5],s[6],s[7],s[8],s[9])
        if a is not None:
            print(a,s)
            rankedsolutions.append((a,s))
            b = GAMS_best/a
            objective.append(np.array([i,b,np.rint(s[0]),round(s[1],2),round(s[2],2),
                                       np.rint(s[3]),round(s[4],2),np.rint(s[0]*s[5]),
                                       np.rint(s[0]*s[6]),np.rint(s[3]*s[7]),
                                       round(s[8],2),round(s[9],2)]))
    rankedsolutions.sort()
    rankedsolutions.reverse()
    print(f"=== Gen {i} best solutions === ", rankedsolutions[0])
    
    #selection
    generation_wise_best_solution.append(rankedsolutions[0])
    #crossover
    child1 = crossover(rankedsolutions)
    #mutation
    new_gen = mutation(new_generation,child1,num=7,probability=0.9)
       
    TimeEnd = time.time()
    TimeCost = TimeEnd - TimeStart
    print(f"=== Gen {i} Time cost === ")
    print(TimeCost)
    solutions = new_gen
Aspen_Plus.close_bkp()
KillAspen()     
# =============================================================================
S8_Simulations = pd.DataFrame(objective)

#parameters_extraction

S8_Simulations.columns = ['Generation number','Objective','NT','R', 'S/F', 'SNT', 'SR',
'Feed Tray(1st Column)', 'Solvent Feed Tray', 'Feed tray(2nd Column)','DIS', 'SDIS']
S8_Simulations.to_excel("C:/Users/sahil/3D Objects/Genetic Algorithm/S8_Simulations.xlsx", index=False)


























