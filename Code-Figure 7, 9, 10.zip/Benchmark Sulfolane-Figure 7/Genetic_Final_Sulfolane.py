# -*- coding: utf-8 -*-
"""
Created on Tue Jun 13 11:47:01 2023

@author: sahil
"""
import os
import time
from win32com.client import GetObject, Dispatch
import numpy as np
import random
from pyDOE import lhs
import pandas as pd
#%%
np.random.seed(10)
random.seed(10)
#%%
#python_aspen_interface functions
class Aspen_Plus_Interface():
    def __init__(self):
        self.Application = Dispatch("Apwn.Document.38.0")
        # {"V10.0": "36.0", V11.0": "37.0", V12.0": "38.0"}
        print(self.Application)

    def load_bkp(self, bkp_file, visible_state=0, dialog_state=0):
        """
        Load a process via bkp file
        :param bkp_file: location of the Aspen Plus file
        :param visible_state: Aspen Plus user interface, 0 is invisible and 1 is visible
        :param dialog_state: Aspen Plus dialogs, 0 is not to suppress and 1 is to suppress
        """
        self.Application.InitFromArchive2(os.path.abspath(bkp_file))
        self.Application.Visible = visible_state
        self.Application.SuppressDialogs = dialog_state

    def re_initialization(self):
        # initial the chemical process in Aspen Plus
        self.Application.Reinit()

    def run_simulation(self):
        # run the process simulation
        self.Application.Engine.Run()

    def check_run_completion(self, time_limit=60):
        # check whether the simulation completed
        times = 0
        while self.Application.Engine.IsRunning == 1:
            time.sleep(1)
            times += 1
            if times >= time_limit:
                print("Violate time limitation")
                self.Application.Engine.Stop
                break

    def check_convergency(self):
        # check the simulation convergency by detecting errors in the history file
        runID = self.Application.Tree.FindNode("\Data\Results Summary\Run-Status\Output\RUNID").Value
        his_file = "C:/Users/sahil/Desktop/Aspen-Python/Sulfolane/" + runID + ".his"
        with open(his_file, "r") as f:
            hasERROR = np.any(np.array([line.find("ERROR") for line in f.readlines()]) >= 0)
        return hasERROR

    def close_bkp(self):
        # close the Aspen Plus file
        self.Application.Quit()

    def collect_stream(self):
        # colloct all streams involved in the process
        streams = []
        node = self.Application.Tree.FindNode(r"\Data\Streams")
        for item in node.Elements:
            streams.append(item.Name)
        return tuple(streams)

    def collect_block(self):
        # colloct all blocks involved in the process
        blocks = []
        node = self.Application.Tree.FindNode(r"\Data\Blocks")
        for item in node.Elements:
            blocks.append(item.Name)
        return tuple(blocks)


def KillAspen():
    # kill the Aspen Plus
    WMI = GetObject("winmgmts:")
    for p in WMI.ExecQuery("select * from Win32_Process where Name='AspenPlus.exe'"):
        os.system("taskkill /pid " + str(p.ProcessId))


def SequenceWithEndPoint(start, stop, step):
    # generate evenly spaced values containing the end point
    return np.arange(start, stop + step, step)


def ListValue2Str(alist):
    # convert a list of mixed variables into string formats
    return list(map(str, alist))

#%%

#genetic algorithm
# load Aspen Plus file
Aspen_Plus = Aspen_Plus_Interface()
Aspen_Plus.load_bkp(r"C:/Users/sahil/Desktop/Aspen-Python/Sulfolane/Sulfolane.bkp", 0, 1)  
def foo(NT,R,StoF,SNT,SR,ff,fs,sff,DIS,SDIS):
    Aspen_Plus.re_initialization()
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\NSTAGE").Value = np.rint(NT)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Input\NSTAGE").Value = np.rint(SNT)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\BASIS_RR").Value = round(R,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Input\BASIS_RR").Value = round(SR,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\SOLVENT\Input\TOTFLOW\MIXED").Value = round(StoF * FeedRate,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\BASIS_D").Value = round(DIS,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Input\BASIS_D").Value = round(SDIS,2)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\FEED_STAGE\FEED").Value = np.rint(ff * NT)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Input\FEED_STAGE\SOLVENT").Value = np.rint(fs * NT)
    Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Input\FEED_STAGE\BOT").Value = np.rint(sff * SNT)

    # run the process simulation
    Aspen_Plus.run_simulation()
    Aspen_Plus.check_run_completion()
    hasERROR = Aspen_Plus.check_convergency()
    
    # collect results
    xD_Eb = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\DIS\Output\MOLEFRAC\MIXED\EB").Value
    SxD_ST = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\SDIS\Output\MOLEFRAC\MIXED\ST").Value
    Di_Eb = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\DIS\Output\MOLEFLOW\MIXED\EB").Value
    Bi_ST = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\BOT\Output\MOLEFLOW\MIXED\ST").Value
    SDi_ST = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\SDIS\Output\MOLEFLOW\MIXED\ST").Value
    SDi_Solvent = Aspen_Plus.Application.Tree.FindNode(r"\Data\Streams\SDIS\Output\MOLEFLOW\MIXED\S31").Value
    
    if xD_Eb>=0.99 and SxD_ST>=0.99 and Di_Eb>=495 and SDi_ST>=0.99*Bi_ST and hasERROR==False:   
        QR = 3600*Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Output\REB_DUTY").Value
        SQR = 3600*Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Output\REB_DUTY").Value
        QC = -1*3600*Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\ED\Output\COND_DUTY").Value
        SQC = -1*3600*Aspen_Plus.Application.Tree.FindNode(r"\Data\Blocks\RECOVERY\Output\COND_DUTY").Value
        SQCC = -1*3600*Aspen_Plus.Application.Tree.FindNode("\Data\Blocks\SQCC\Output\QCALC").Value
        
        CED = 56910*((QR/(100*30*2249.28))**0.71)  + 56910*((QC/(100*30.26*2249.28))**0.71)+ 81300*((((4+0.5*NT)*(((4+0.5*NT)/10)**1.5))/20)**0.81) + 2439*NT* (((((4+0.5*NT)/10)**1.5)/2.13)**0.8)
        CSR = 56910*((SQR/(100*30*2249.28))**0.71)  + 56910*((SQC/(100*30.26*2249.28))**0.71)+ 81300*((((4+0.5*SNT)*(((4+0.5*SNT)/10)**1.5))/20)**0.81) + 2439*SNT* (((((4+0.5*SNT)/10)**1.5)/2.13)**0.8)
        CHE = 56910*((SQCC/(100*30.26*2249.28))**0.71)
        
        OBJ = 0.064 * (QR + SQR) + 0.002832 * (QC + SQC) + 1.127 * (CED + CSR) + 0.002832 * SQCC + 1.127 * CHE
        fitness_value = OBJ

        return fitness_value

def fitness(NT,R,StoF,SNT,SR,ff,fs,sff,DIS,SDIS):
    ans = foo(NT,R,StoF,SNT,SR,ff,fs,sff,DIS,SDIS)
    if ans is not None:
      return(11457000/ans)
  
def crossover(bestsolution):
    parent1 = np.array(bestsolution[0][1])
    parent2 = np.array(bestsolution[1][1])
    noOFCol = len(parent1)
    child1 = np.zeros(noOFCol)
 
    #crossoversite
    crossSite = random.randrange(1,noOFCol-1)
    for i in range(noOFCol):
        if i>=crossSite:
            child1[i] = parent2[i]
        else:
            child1[i] = parent1[i]
    return child1

def mutation(new_generations,child,num,probability):
    new_gen = []
    for _ in range((new_generations)):
        for _ in range(num):
            index = random.randrange(len(list(child)))
            a = np.random.random()
            if a>probability:
                child[index] = child[index]
            else:
                child[index] = child[index]*np.random.uniform(0.99,1.01)
        new_gen.append(tuple(child))
    return new_gen

#%%
#generate solutions/samples  using lhs
number_of_generations = 200
new_generation = 20
num_initial_samples = 100 #population used in lhs
GAMS_best = 11457000
NT =   list(np.linspace(51,61,10))           # number of stages in 1st column
R =    list(np.linspace(1.77,2.57,10))      # reflux ratio in 1st column
StoF = list(np.linspace(0.97,1.97,10))     # solvent to feed ratio
SNT =  list(np.linspace(5,11,7))             # number of trays in 2nd column
SR =   list(np.linspace(0.01,0.1,10))       # reflux ratio of 2nd column
ff =   list(np.linspace(0.45,0.55,10))        # feed stage of feed mixture in 1st column
fs =   list(np.linspace(0.24,0.34,10))        # feed stage of solvent
sff =  list(np.linspace(0.28,0.48,10))        # feed stage of 2nd column
DIS =  list(np.linspace(495,505,10))          # Distillate of 1st column
SDIS = list(np.linspace(485,505,10))         # Distillate of 2nd column
# Define the inputs and their possible values
inputs = {
    'NT': NT,'R' : R, 'StoF' : StoF, 'SNT': SNT, 'SR' : SR,
    'ff' : ff, 'fs' : fs, 'sff': sff,'DIS' : DIS, 'SDIS': SDIS
}


#genetic algorithm
# Step:1 Generate the Latin Hypercube sample for initial population
lhs_sample = lhs(len(inputs), samples=num_initial_samples)

# Create the initial population using exact values of each input
solutions = []
rankedsolutions = []
for i in range(num_initial_samples):
    sample = tuple([inputs[key][int(lhs_sample[i][j] * len(inputs[key]))] for j, key in enumerate(inputs.keys())])
    solutions.append(sample)
# calculating fitness
generation_wise_best_solution = []
total_iterations = []
objective = []
rankedsolutions = []
FeedRate = 1000
# =============================================================================
# solutions.append((56.92060396983833, 2.1899249563861716, 1.415154963321846, 9.796485254980883, 0.09322918057244524, 0.5201376386906862, 0.2774859063426543, 0.3148781000526104, 500.3367372155299, 495.77771602093276))
# solutions.append((56.59862473109245, 2.1900752626040543, 1.415874128608516, 9.844240322302833, 0.09470225137753199, 0.5229494235649316, 0.27573356012071765, 0.3117488548076188, 501.9053238503263, 495.77771602093276))
# solutions.append((57.24521731761668, 2.1716429974668503, 1.387762199419328, 9.757703498995717, 0.09089930212137723, 0.5226520227534788, 0.2829727675086765, 0.31650130958357237, 501.04366107923306, 495.115023982028))
# 
# =============================================================================

print("Start simulation ...")
for i in range(number_of_generations):
    TimeStart = time.time()
    new_gen = []
    for s in solutions:
        print(solutions.index(s))
        a = fitness(s[0],s[1],s[2],s[3],s[4],s[5],s[6],s[7],s[8],s[9])
        if a is not None:
            print(a,s)
            rankedsolutions.append((a,s))
            total_iterations.append([i,a,s])
            b = GAMS_best/a
            objective.append(np.array([i,b,np.rint(s[0]),round(s[1],2),round(s[2],2),
                                       np.rint(s[3]),round(s[4],2),np.rint(s[0]*s[5]),
                                       np.rint(s[0]*s[6]),np.rint(s[3]*s[7]),
                                       round(s[8],2),round(s[9],2)]))
    rankedsolutions.sort()
    rankedsolutions.reverse()
    print(f"=== Gen {i} best solutions === ", rankedsolutions[0])
    
    #selection
    generation_wise_best_solution.append(rankedsolutions[0])
    #crossover
    child1 = crossover(rankedsolutions)
    #mutation
    new_gen = mutation(new_generation,child1,num=7,probability=0.9)
       
    TimeEnd = time.time()
    TimeCost = TimeEnd - TimeStart
    print(f"=== Gen {i} Time cost === ")
    print(TimeCost)
    solutions = new_gen
Aspen_Plus.close_bkp()
KillAspen()     
# =============================================================================
Sulfolane_Simulations = pd.DataFrame(objective)

#parameters_extraction

Sulfolane_Simulations.columns = ['Generation number','Objective','NT','R', 'S/F', 'SNT', 'SR',
'Feed Tray(1st Column)', 'Solvent Feed Tray', 'Feed tray(2nd Column)','DIS', 'SDIS']
Sulfolane_Simulations.to_excel("C:/Users/sahil/3D Objects/Genetic Algorithm/Sulfolane_Simulations.xlsx", index=False)


























